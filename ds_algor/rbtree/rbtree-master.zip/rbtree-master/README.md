rbtree
======

rbtree implementation adapted from linux kernel thus can be used in your own c program(of course in userspace).