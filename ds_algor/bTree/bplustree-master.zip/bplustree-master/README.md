B+Tree
======

A minimal B+Tree implementation for key-value storage.

Demo
----

```shell
./demo_build.sh
```

General Test
------------

```shell
./test_build.sh
```

Code Coverage Test
------------------

```shell
./coverage_build.sh
```
